let lang='en';const btn=document.getElementById('langBtn');
function applyLang(){document.querySelectorAll('[data-en]').forEach(e=>e.textContent=lang==='en'?e.dataset.en:e.dataset.gu);btn.textContent=lang==='en'?'ગુજરાતી':'English';document.documentElement.lang=lang==='en'?'en':'gu'}
btn.addEventListener('click',()=>{lang=lang==='en'?'gu':'en';applyLang()});
document.getElementById('bookingForm').addEventListener('submit',e=>{e.preventDefault();const n=document.getElementById('name').value.trim(),p=document.getElementById('phone').value.trim(),ev=document.getElementById('event').value.trim(),d=document.getElementById('date').value,m=document.getElementById('message').value.trim();const text=`Hello Shiv Rajwadi Saafa,\n\nName: ${n}\nMobile: ${p}\nEvent: ${ev}\nDate: ${d}\nMessage: ${m}`;window.open('https://wa.me/?text='+encodeURIComponent(text),'_blank')});
applyLang();
